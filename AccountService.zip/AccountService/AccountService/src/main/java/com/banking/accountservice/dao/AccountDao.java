package com.banking.accountservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.banking.accountservice.model.Account;



public interface AccountDao extends JpaRepository<Account, Long> {

}
