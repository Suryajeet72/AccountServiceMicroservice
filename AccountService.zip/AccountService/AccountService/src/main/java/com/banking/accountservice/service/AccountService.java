package com.banking.accountservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.banking.accountservice.dao.AccountDao;
import com.banking.accountservice.exception.NoRecordsException;
import com.banking.accountservice.model.Account;

public class AccountService {

	@Autowired
	private AccountDao dao;

	public boolean addAccount(Account acc) {
		Account acc1 = dao.save(acc);
		if (acc1 != null)
			return true;
		else
			return false;
	}

	public boolean updateAccount(Account acc) {
		Account acc1 = dao.save(acc);
		if (acc1 != null)
			return true;
		else
			return false;
	}

	public List<Account> getAllAccount() {
		List<Account> list = dao.findAll();
		if (list.isEmpty()) {
			throw new NoRecordsException("No records found");
		} else {
			return list;
		}
	}

	public boolean deleteAccount(long accNum) {
		dao.deleteById(accNum);
		Optional<Account> cus = dao.findById(accNum);
		Account acc = cus.get();
		if (acc == null) {
			return true;
		} else {
			throw new NoRecordsException("No record to delete");
		}
	}

	public boolean deleteAll() {
		dao.deleteAll();
		return true;
	}

}
