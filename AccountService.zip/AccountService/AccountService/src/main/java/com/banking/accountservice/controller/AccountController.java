package com.banking.accountservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.banking.accountservice.model.Account;
import com.banking.accountservice.model.AccountDTO;
import com.banking.accountservice.service.AccountService;

@RequestMapping("/accountconroller")
public class AccountController {
	@Autowired
	private AccountService service;

	@PostMapping("/create")
	public ResponseEntity<Object> addAccount(@RequestBody Account acc) // http://localhost:8080/customer/createCustomer
	{
		System.out.println("Account Brnch"+acc.getAccBranch());
		// return cusService.createCustomer(customer);
		if (service.addAccount(acc)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		} else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}

	@PutMapping("/update")
	public ResponseEntity<Object> updateAccount(@RequestBody Account acc) {
		if (service.updateAccount(acc)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		} else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}

	@DeleteMapping("/delete/{accnum}")
	public ResponseEntity<Object> deleteAccount(@PathVariable("accnum") long accNum) {
		service.deleteAccount(accNum);
		return new ResponseEntity<Object>("Deleted", HttpStatus.NO_CONTENT);
	}

	@GetMapping("/accounts")
	public ResponseEntity<AccountDTO> getAllAccount() {
		AccountDTO dto = new AccountDTO();
		dto.setList(service.getAllAccount());
		return new ResponseEntity<AccountDTO>(dto, HttpStatus.OK);
	}
	@DeleteMapping("/deleteAll")
	public ResponseEntity<Object> deleteAll(){
		service.deleteAll();
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
	}
}
