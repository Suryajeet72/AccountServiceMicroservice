package com.banking.accountservice.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//{
//    "accNumber":444444,
//    "accBalance":40000,
//    "accBranch":"aundh",
//    "accOpenDate":"01-01-2020",
//    "accType":"saving"
// 
//}
@Entity
@Table(name = "accounts")
public class Account {

	@Id
	private long accNumber;
	private double accBalance;
	private String accBranch;
	private LocalDate accOpenDate = LocalDate.now();
	private String accType;

	public Account() {
		super();
	}

	public Account(long accNumber, double accBalance, String accBranch, String accType) {
		super();
		this.accNumber = accNumber;
		this.accBalance = accBalance;
		this.accBranch = accBranch;
		this.accType = accType;
	}

	public Account(long accNumber, double accBalance, String accBranch, LocalDate accOpenDate, String accType) {
		super();
		this.accNumber = accNumber;
		this.accBalance = accBalance;
		this.accBranch = accBranch;
		this.accOpenDate = accOpenDate;
		this.accType = accType;
	}

	public long getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}

	public double getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	public String getAccBranch() {
		return accBranch;
	}

	public void setAccBranch(String accBranch) {
		this.accBranch = accBranch;
	}

	public LocalDate getAccOpenDate() {
		return accOpenDate;
	}

	public void setAccOpenDate(LocalDate accOpenDate) {
		this.accOpenDate = accOpenDate;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	@Override
	public String toString() {
		return String.format("Account [accNumber=%s, accBalance=%s, accBranch=%s, accOpenDate=%s, accType=%s]",
				accNumber, accBalance, accBranch, accOpenDate, accType);
	}

}
